<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessories</title>
    <link rel="shortcut icon" type="image" href="Images/logo.jpg">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="Style.css">
  
</head>
<body>
    <header>
        <marquee behaviour="scroll"  dir="auto" scrollamount='20'  style="background-color: rgb(247, 92, 92);"> <h3>Beauty & Makeup Sale Live Now !!</h3> </marquee>
    
        <div class="header-container">
            <div class="logoimg">
                <img src="Images/fulllogo.png" alt="logo" width="300" height="100">
            </div>
            <div class="login">
                <a class="login" href="loginsignup.php"><i class='bx bx-user-circle'></i>Login</a>
    
            </div>
            <div class="cart-container">
            <button onclick="toggleCart()" class="toggle-cart-btn">Cart</button>
            <div class="cart" id="cart">
                <h3>Your Cart</h3>
                <div id="cart-items"></div>
                <div class="total-bill" id="total-bill">Total: $0</div>
                <button onclick="checkout()">Checkout</button>
            </div>
        </div>
            <div class="menu">
                <ul class="hdul">
                <li class="hdli"><a href="index.php">Home</a></li>
                    <li class="hdli"><a href="deal.php">Deals</a></li>
                    <li class="dropdown hdli">
                    <a href="#" class="dropbtn" onclick="return false;" style="pointer-events: none; ">Beauty</a>
                        <div class="dropdown-content">
                            <a href="makeup.php">Makeup</a>
                            <a href="skincare.php">Skincare</a>
                         
                        </div>
                    </li>
                    <li class="hdli">  <a href="fragnances.php">Fragnance</a></li>
                    <li class="hdli"> <a href="accessories.php">Accessories</a></li>
                </ul>
    
            </div></div>
        </header> <hr>
         <!-- Whatsaapp-->
         <div class="cont">
        <div class="nbox" id="box2"><a href="https://wa.me/923319512381"><i class='bx bxl-whatsapp-square' style='color:#31a80c'  ></i></a></div>

           <!-- carts-->
    <div class="container">
      
        <div class="cards" id="product-cards"></div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="deal.php">Deals</a></li>
                        <li><a href="#">Reviews</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Get help</h4>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">shipping</a></li>
                        <li><a href="#">returns</a></li>
                        <li><a href="#">order status</a></li>
                        <li><a href="#">payment options</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contact</h4>
                    <ul>
                        <li><i class='bx bxl-whatsapp smi ' style='color:#3e7137'></i>+92 3319512381</li>
                        <li><i class='bx bxl-youtube smi' style='color:#ea1d11'></i>Soulshine Cosmestics
                        </li>
                        <li><i class='bx bxl-instagram-alt  smi' style='color:#e311ea'></i> Soulshine_pk
                        </li>
                        <li><i class='bx bxl-facebook smi' style='color:#3446ea'></i>Soulshine</li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <p>Feel free to follow us on Social Media . <br> All links are given below</p> <br>
                        <a href="https://www.instagram.com/soulshine_pk"><i class='bx bxl-instagram-alt  smi'
                                style='color:#e311ea'></i></a>
                        <a href="https://www.facebook.com/profile.php"><i class='bx bxl-facebook smi'
                                style='color:#3446ea'></i></a>
                        <a href="https://youtube.com/@soulshine_pk"><i class='bx bxl-youtube smi'
                                style='color:#ea1d11'></i></a>
                        <a href="https://wa.me/923319512381"><i class='bx bxl-whatsapp smi ' style='color:#3e7137'></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script>
        

const products = [
    { id: 1, name: "Product 1", description: "Great product", price: 100, image: "https://via.placeholder.com/150" },
    { id: 2, name: "Product 2", description: "Another great product", price: 150, image: "https://via.placeholder.com/150" },
    { id: 3, name: "Product 3", description: "Amazing product", price: 200, image: "https://via.placeholder.com/150" }
];

const cart = [];

function renderProducts() {
    const productContainer = document.getElementById('product-cards');
    productContainer.innerHTML = '';
    products.forEach(product => {
        productContainer.innerHTML += `
            <div class="card">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p><strong>Price:</strong> $${product.price}</p>
                <button id="add-btn-${product.id}" onclick="addToCart(${product.id}, this)">Add to Cart</button>
            </div>`;
    });
}

function renderCart() {
    const cartContainer = document.getElementById('cart-items');
    const totalBillElement = document.getElementById('total-bill');
    const checkoutButton = document.querySelector('button[onclick="checkout()"]');
    cartContainer.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        total += item.price * item.quantity;
        cartContainer.innerHTML += `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <h4>${item.name}</h4>
                <p>${item.price} x ${item.quantity}</p>
                <button onclick="removeFromCart(${item.id})">Remove</button>
            </div>`;
    });

    totalBillElement.textContent = `Total: $${total}`;

    // Disable checkout button if cart is empty
    if (cart.length === 0) {
        checkoutButton.disabled = true;
        checkoutButton.style.backgroundColor = "#ccc"; // Change the button color to show it's disabled
    } else {
        checkoutButton.disabled = false;
        checkoutButton.style.backgroundColor = "#28a745"; // Revert to original color when enabled
    }
}

function addToCart(productId, button) {
    const product = products.find(p => p.id === productId);
    const cartItem = cart.find(c => c.id === productId);

    if (cartItem) {
        cartItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    // Visual feedback
    button.textContent = "Added!";
    button.disabled = true;
    setTimeout(() => {
        button.textContent = "Add to Cart";
        button.disabled = false;
    }, 2000);

    renderCart();
}

function removeFromCart(productId) {
    const index = cart.findIndex(c => c.id === productId);
    if (index !== -1) {
        cart.splice(index, 1);
    }
    renderCart();
}

function toggleCart() {
    const cartElement = document.getElementById('cart');
    cartElement.style.display = cartElement.style.display === 'block' ? 'none' : 'block';
}

function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty! Please add products to your cart before checking out.");
        return; // Prevent going to checkout if cart is empty
    }

    // Save cart details to localStorage
    localStorage.setItem("cart", JSON.stringify(cart));
    // Redirect to checkout page
    window.location.href = "try2.html";
}

renderProducts();
renderCart();

    </script>
</body>
</html>