<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Checkout Process</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            display: flex;
            justify-content: space-between;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        .form-container, .cart-container {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 45%;
        }
        .cart-container h3, .form-container h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        .total-bill {
            text-align: center;
            margin-top: 20px;
            font-weight: bold;
            font-size: 18px;
        }
        .form-container label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }
        .form-container input,
        .form-container textarea {
            width: 100%;
            margin-top: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .form-container .payment-methods {
            margin: 20px 0;
            font-weight: bold;
        }
        .form-container button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 48%;
        }
        .form-container .confirm-btn {
            background: #28a745;
            color: #fff;
        }
        .form-container .confirm-btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
        }
        .form-container .confirm-btn:hover:not(:disabled) {
            background: #218838;
        }
        .form-container .cancel-btn {
            background: #dc3545;
            color: #fff;
        }
        .form-container .cancel-btn:hover {
            background: #c82333;
        }
        /* Responsive layout for smaller screens */
        @media screen and (max-width: 768px) {
            .container {
                flex-direction: column;
                align-items: center;
            }
            .form-container, .cart-container {
                width: 80%;
                margin-bottom: 20px;
            }
        }
        .cart-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #ddd;
}

.item-details {
    display: flex;
    align-items: center;
    width: 40%;
}

.item-image {
    width: 60px;
    height: 60px;
    margin-right: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.item-info {
    display: flex;
    flex-direction: column;
}

.item-name {
    font-weight: bold;
    margin-bottom: 5px;
}

.item-price {
    color: #333;
    font-size: 14px;
}

.item-quantity {
    display: flex;
    align-items: center;
}

.qty-btn {
    width: 30px;
    height: 30px;
    background-color: #f8f9fa;
    border: 1px solid #ddd;
    font-size: 18px;
    cursor: pointer;
}

.item-delete .delete-btn {
    color: #dc3545;
    background: none;
    border: none;
    cursor: pointer;
}

.item-subtotal {
    font-weight: bold;
    color: #333;
}

    </style>
</head>
<body>
  

    <div class="container">
        <!-- Customer Details Form (Left side) -->
        <div class="form-container">
            <h3>Checkout Processing</h3>
            <form id="checkout-form">
                <label for="name">Name</label>
                <input type="text" id="name" placeholder="Enter your full name" required>
                
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" placeholder="Enter your phone number" required>
                
                <label for="city">City</label>
                <input type="text" id="city" placeholder="Enter your city" required>
                
                <label for="address">Address</label>
                <textarea id="address" rows="3" placeholder="Enter your full address" required></textarea>
                
                <label for="upload">Upload Payment Screenshot</label>
                <input type="file" id="upload" accept="image/*" required>
                
                <div class="payment-methods">
                    <p><strong>Payment Methods:</strong></p>
                    <p>Bank Transfer: Allied Bank Azka Noor, Account No: 756352546768</p>
                    <p>Easypaisa: Azka Noor, Account No: 4653636526</p>
                </div>
                <button type="button" class="cancel-btn" onclick="cancelOrder()">Cancel</button>
                <button type="submit" class="confirm-btn" id="confirm-order-btn" disabled>Confirm Order</button>
            </form>
        </div>

        <!-- Cart Details (Right side) -->
        <div class="cart-container">
            <h3>Your Cart</h3>
            <div id="cart-items"></div>
            <div class="total-bill" id="total-bill">Total: $0</div>
        </div>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="deal.php">Deals</a></li>
                        <li><a href="#">Reviews</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Get help</h4>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">shipping</a></li>
                        <li><a href="#">returns</a></li>
                        <li><a href="#">order status</a></li>
                        <li><a href="#">payment options</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contact</h4>
                    <ul>
                        <li><i class='bx bxl-whatsapp smi ' style='color:#3e7137'></i>+92 3319512381</li>
                        <li><i class='bx bxl-youtube smi' style='color:#ea1d11'></i>Soulshine Cosmestics
                        </li>
                        <li><i class='bx bxl-instagram-alt  smi' style='color:#e311ea'></i> Soulshine_pk
                        </li>
                        <li><i class='bx bxl-facebook smi' style='color:#3446ea'></i>Soulshine</li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>follow us</h4>
                    <div class="social-links">
                        <p>Feel free to follow us on Social Media . <br> All links are given below</p> <br>
                        <a href="https://www.instagram.com/soulshine_pk"><i class='bx bxl-instagram-alt  smi'
                                style='color:#e311ea'></i></a>
                        <a href="https://www.facebook.com/profile.php"><i class='bx bxl-facebook smi'
                                style='color:#3446ea'></i></a>
                        <a href="https://youtube.com/@soulshine_pk"><i class='bx bxl-youtube smi'
                                style='color:#ea1d11'></i></a>
                        <a href="#"><i class='bx bxl-whatsapp smi ' style='color:#3e7137'></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <script>
        try {
            // Load cart details from localStorage with error handling
            const cart = JSON.parse(localStorage.getItem("cart")) || [];
            const cartContainer = document.getElementById("cart-items");
            const totalBillElement = document.getElementById("total-bill");
            const confirmOrderButton = document.getElementById("confirm-order-btn");

            // Render cart items and update total
            function renderCart() {
                try {
                    cartContainer.innerHTML = ''; // Clear the cart display
                    let total = 0;

                    cart.forEach((item, index) => {
                        total += item.price * item.quantity;
                        cartContainer.innerHTML += `
                            <div class="cart-item">
                                <div class="item-details">
                                    <img src="${item.image}" alt="${item.name}" class="item-image">
                                    <div class="item-info">
                                        <p class="item-name">${item.name}</p>
                                        <p class="item-name"> ID: ${item.id}</p>
                                        <p class="item-price">Rs.${item.price}</p>
                                    </div>
                                </div>
                                <div class="item-quantity">
                                    <button class="qty-btn" onclick="updateQuantity(${index}, -1)">-</button>
                                    <span>${item.quantity}</span>
                                    <button class="qty-btn" onclick="updateQuantity(${index}, 1)">+</button>
                                </div>
                                <div class="item-delete">
                                    <button class="delete-btn" onclick="deleteItem(${index})">Delete</button>
                                </div>
                                <div class="item-subtotal">
                                    Rs.${item.price * item.quantity}
                                </div>
                            </div>
                        `;
                    });

                    totalBillElement.textContent = `Total: Rs.${total}`;

                    // Disable confirm button if total is 0
                    if (total === 0) {
                        confirmOrderButton.disabled = true;
                        confirmOrderButton.style.backgroundColor = "#cccccc"; // Disabled style
                    } else {
                        confirmOrderButton.disabled = false;
                        confirmOrderButton.style.backgroundColor = "#28a745"; // Enabled style
                    }
                } catch (error) {
                    console.error("Error rendering cart items:", error);
                    alert("An error occurred while rendering the cart. Please try again.");
                }
            }

            // Function to update quantity with error handling
            function updateQuantity(index, change) {
                try {
                    if (cart[index].quantity + change > 0) {
                        cart[index].quantity += change;
                        renderCart();
                    }
                } catch (error) {
                    console.error(`Error updating quantity for item ${index}:`, error);
                    alert("An error occurred while updating the quantity. Please try again.");
                }
            }

            // Function to delete item with error handling
            function deleteItem(index) {
                try {
                    cart.splice(index, 1);
                    renderCart();
                } catch (error) {
                    console.error(`Error deleting item ${index}:`, error);
                    alert("An error occurred while deleting the item. Please try again.");
                }
            }

            // Call renderCart to load the initial state
            renderCart();

            // Cancel Order: Redirect to index page with error handling
            function cancelOrder() {
                try {
                    window.location.href = "index.php";
                } catch (error) {
                    console.error("Error canceling the order:", error);
                    alert("An error occurred while canceling the order. Please try again.");
                }
            }

            // Confirm Order: Show success popup with error handling
            document.getElementById("checkout-form").addEventListener("submit", function(event) {
                event.preventDefault();
                try {
                    if (cart.length === 0) {
                        alert("Your cart is empty. Please add items to your cart before proceeding.");
                        return;
                    }
                    alert("Order is successfully done!");
                    localStorage.removeItem("cart");
                    window.location.href = "index.php";
                } catch (error) {
                    console.error("Error confirming the order:", error);
                    alert("An error occurred while confirming the order. Please try again.");
                }
            });
        } catch (error) {
            console.error("Error initializing the checkout page:", error);
            alert("An error occurred while loading the page. Please refresh the page and try again.");
        }
    </script>
</body>
</html>

